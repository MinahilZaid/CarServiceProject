package Project;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import java.time.LocalDate;
import java.util.List;

@Entity
public class Booking {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	private long booking_ID;
	private String cust_name;
	private String cust_email;
	private String service;
	private LocalDate date;
	private String special_req;
	
	 public Booking() {
	    }

	public Booking(long booking_ID, String cust_name, String cust_email, String service, LocalDate date,
			String special_req) {
		super();
		this.booking_ID = booking_ID;
		this.cust_name = cust_name;
		this.cust_email = cust_email;
		this.service = service;
		this.date = date;
		this.special_req = special_req;
	}

	public long getBooking_ID() {
		return booking_ID;
	}

	public void setBooking_ID(long booking_ID) {
		this.booking_ID = booking_ID;
	}

	public String getCust_name() {
		return cust_name;
	}

	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}

	public String getCust_email() {
		return cust_email;
	}

	public void setCust_email(String cust_email) {
		this.cust_email = cust_email;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getSpecial_req() {
		return special_req;
	}

	public void setSpecial_req(String special_req) {
		this.special_req = special_req;
	}

	

}
