package Project;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

	
	@CrossOrigin

	@RestController

	public class ContactController {
		@Autowired
		private final ContactService contactService;
		
		

	    public ContactController(ContactService contactService) {
			super();
			this.contactService = contactService;
		}
	    
	    @GetMapping("getcontacts")

	    public List<Contact> getContact() {
	    	
	        return contactService.getContacts();
	    }

	    @PostMapping("addcontacts")

	    public void addcontacts(@RequestBody Contact contact)
	    {
	    	contactService.addcontacts(contact);
	    }
	    
	    @PutMapping("updatecontact/{id}")
	    public void updatecontact(@RequestBody Contact updatedcontact , @PathVariable Long id )
	    {
	    	contactService.updatecontact(updatedcontact,id );

	    }
	    
	    @DeleteMapping("deletecontact/{id}")
	    public void deletecontact(@PathVariable Long id )
	   {
	    	contactService.deletecontact(id);
	   }


	}
