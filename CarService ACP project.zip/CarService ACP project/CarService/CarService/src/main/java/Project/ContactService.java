package Project;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

	@Service

	public class ContactService {
		@Autowired
		private  ContactRepository contactRepository;
		 public List<Contact> getContacts() 
		 {
			 
			 List<Contact> contacts = new ArrayList<Contact>();
				contactRepository.findAll().forEach(contacts::add);
			    return contacts;
		    }
		 
		public void addcontacts(Contact contacts)
		{
			contactRepository.save(contacts);
			
		}
		
		public void updatecontact(Contact updatedcontact, Long id) {
			Optional<Contact> existingContactOptional = contactRepository.findById(id);
			if (existingContactOptional.isPresent()) {
			Contact existingContact = existingContactOptional.get();
			existingContact.setName(updatedcontact.getName());
			existingContact.setEmail(updatedcontact.getEmail());;
			existingContact.setMessage(updatedcontact.getMessage());;
			contactRepository.save(existingContact);
			
			}
			
		}

		public void deletecontact(Long id)
		 {
			contactRepository.deleteById(id);
		}


	}

