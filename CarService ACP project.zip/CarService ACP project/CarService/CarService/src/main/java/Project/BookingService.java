package Project;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//import org.springframework.web.bind.annotation.PathVariable;

@Service

public class BookingService {
	@Autowired
	private BookingRepository bookingRepository;
	 public List<Booking> getBooking() 
	 {
		 
		 List<Booking> bookings = new ArrayList<Booking>();
		 bookingRepository.findAll().forEach(bookings::add);
		    return bookings;
	    }
	 
	public void addbooking(Booking bookings)
	{
		bookingRepository.save(bookings);
	}
	

	public void updatebooking(Booking updatedbooking, Long booking_ID) {
		Optional<Booking> existingBookingOptional = bookingRepository.findById(booking_ID);
		if (existingBookingOptional.isPresent()) {
		Booking existingBooking = existingBookingOptional.get();
		 existingBooking.setCust_name(updatedbooking.getCust_name());
         existingBooking.setCust_email(updatedbooking.getCust_email());
         existingBooking.setDate(updatedbooking.getDate());
         existingBooking.setService(updatedbooking.getService());
         existingBooking.setSpecial_req(updatedbooking.getSpecial_req());
         
		bookingRepository.save(existingBooking);
		}
		
	}

	public void deletebooking(Long booking_ID)
	 {
		bookingRepository.deleteById(booking_ID);
	}



}
